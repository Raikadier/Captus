﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITY
{
    public class Priority
    {
        public int Id_Priority { get; set; }
        public string Name { get; set; }
    }
}
