﻿namespace Presentation
{
    partial class frmRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegister));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnReply = new System.Windows.Forms.PictureBox();
            this.txtCnPassword = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPhNumber = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnRestaurar = new System.Windows.Forms.Button();
            this.btnMaximizarbtnMaximizar = new System.Windows.Forms.Button();
            this.btnMinimizar = new System.Windows.Forms.Button();
            this.btnClse = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.brnCmPassword = new System.Windows.Forms.PictureBox();
            this.brnPassword = new System.Windows.Forms.PictureBox();
            this.brnUserName = new System.Windows.Forms.PictureBox();
            this.brnPhNumber = new System.Windows.Forms.PictureBox();
            this.brnEmail = new System.Windows.Forms.PictureBox();
            this.brnLastName = new System.Windows.Forms.PictureBox();
            this.BnrName = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnReply)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRegister)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnCmPassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnPassword)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnUserName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnPhNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnEmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnLastName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BnrName)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Honeydew;
            this.panel1.Controls.Add(this.btnReply);
            this.panel1.Controls.Add(this.txtCnPassword);
            this.panel1.Controls.Add(this.txtPassword);
            this.panel1.Controls.Add(this.txtUsername);
            this.panel1.Controls.Add(this.txtPhNumber);
            this.panel1.Controls.Add(this.txtEmail);
            this.panel1.Controls.Add(this.txtLastName);
            this.panel1.Controls.Add(this.txtName);
            this.panel1.Controls.Add(this.btnRegister);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.brnCmPassword);
            this.panel1.Controls.Add(this.brnPassword);
            this.panel1.Controls.Add(this.brnUserName);
            this.panel1.Controls.Add(this.brnPhNumber);
            this.panel1.Controls.Add(this.brnEmail);
            this.panel1.Controls.Add(this.brnLastName);
            this.panel1.Controls.Add(this.BnrName);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1200, 650);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnReply
            // 
            this.btnReply.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReply.Image = global::Presentation.Properties.Resources.btnReply;
            this.btnReply.Location = new System.Drawing.Point(37, 102);
            this.btnReply.Name = "btnReply";
            this.btnReply.Size = new System.Drawing.Size(39, 38);
            this.btnReply.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnReply.TabIndex = 29;
            this.btnReply.TabStop = false;
            this.btnReply.Click += new System.EventHandler(this.btnReply_Click);
            // 
            // txtCnPassword
            // 
            this.txtCnPassword.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCnPassword.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtCnPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCnPassword.Location = new System.Drawing.Point(592, 486);
            this.txtCnPassword.Name = "txtCnPassword";
            this.txtCnPassword.Size = new System.Drawing.Size(168, 13);
            this.txtCnPassword.TabIndex = 28;
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtPassword.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPassword.Location = new System.Drawing.Point(591, 419);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(170, 13);
            this.txtPassword.TabIndex = 27;
            // 
            // txtUsername
            // 
            this.txtUsername.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtUsername.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUsername.Location = new System.Drawing.Point(588, 356);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(178, 13);
            this.txtUsername.TabIndex = 26;
            // 
            // txtPhNumber
            // 
            this.txtPhNumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtPhNumber.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPhNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPhNumber.Location = new System.Drawing.Point(593, 293);
            this.txtPhNumber.Name = "txtPhNumber";
            this.txtPhNumber.Size = new System.Drawing.Size(170, 13);
            this.txtPhNumber.TabIndex = 25;
            // 
            // txtEmail
            // 
            this.txtEmail.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtEmail.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.Location = new System.Drawing.Point(591, 235);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(170, 13);
            this.txtEmail.TabIndex = 24;
            // 
            // txtLastName
            // 
            this.txtLastName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtLastName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtLastName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLastName.Location = new System.Drawing.Point(592, 177);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(166, 13);
            this.txtLastName.TabIndex = 23;
            // 
            // txtName
            // 
            this.txtName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtName.Location = new System.Drawing.Point(592, 123);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(166, 13);
            this.txtName.TabIndex = 22;
            // 
            // btnRegister
            // 
            this.btnRegister.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnRegister.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegister.Image = global::Presentation.Properties.Resources.btnRegister;
            this.btnRegister.Location = new System.Drawing.Point(507, 526);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(217, 134);
            this.btnRegister.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnRegister.TabIndex = 21;
            this.btnRegister.TabStop = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Honeydew;
            this.panel2.Controls.Add(this.btnRestaurar);
            this.panel2.Controls.Add(this.btnMaximizarbtnMaximizar);
            this.panel2.Controls.Add(this.btnMinimizar);
            this.panel2.Controls.Add(this.btnClse);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1200, 76);
            this.panel2.TabIndex = 19;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel2_MouseDown);
            // 
            // btnRestaurar
            // 
            this.btnRestaurar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRestaurar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRestaurar.FlatAppearance.BorderSize = 0;
            this.btnRestaurar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnRestaurar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnRestaurar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRestaurar.Image = global::Presentation.Properties.Resources.btnRestaurar;
            this.btnRestaurar.Location = new System.Drawing.Point(1132, 5);
            this.btnRestaurar.Name = "btnRestaurar";
            this.btnRestaurar.Size = new System.Drawing.Size(30, 35);
            this.btnRestaurar.TabIndex = 38;
            this.btnRestaurar.UseVisualStyleBackColor = true;
            this.btnRestaurar.Visible = false;
            this.btnRestaurar.Click += new System.EventHandler(this.btnRestaurar_Click_1);
            // 
            // btnMaximizarbtnMaximizar
            // 
            this.btnMaximizarbtnMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximizarbtnMaximizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaximizarbtnMaximizar.FlatAppearance.BorderSize = 0;
            this.btnMaximizarbtnMaximizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnMaximizarbtnMaximizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnMaximizarbtnMaximizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximizarbtnMaximizar.Image = global::Presentation.Properties.Resources.icons8_maximize_window_50__1_;
            this.btnMaximizarbtnMaximizar.Location = new System.Drawing.Point(1131, 3);
            this.btnMaximizarbtnMaximizar.Name = "btnMaximizarbtnMaximizar";
            this.btnMaximizarbtnMaximizar.Size = new System.Drawing.Size(30, 35);
            this.btnMaximizarbtnMaximizar.TabIndex = 37;
            this.btnMaximizarbtnMaximizar.UseVisualStyleBackColor = true;
            this.btnMaximizarbtnMaximizar.Click += new System.EventHandler(this.btnMaximizarbtnMaximizar_Click);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimizar.FlatAppearance.BorderSize = 0;
            this.btnMinimizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnMinimizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimizar.Image = global::Presentation.Properties.Resources.btnMinimizar;
            this.btnMinimizar.Location = new System.Drawing.Point(1103, 9);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(23, 25);
            this.btnMinimizar.TabIndex = 36;
            this.btnMinimizar.UseVisualStyleBackColor = true;
            // 
            // btnClse
            // 
            this.btnClse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClse.FlatAppearance.BorderSize = 0;
            this.btnClse.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnClse.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnClse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClse.Image = global::Presentation.Properties.Resources.icons8_close_window_50__2_;
            this.btnClse.Location = new System.Drawing.Point(1164, 8);
            this.btnClse.Name = "btnClse";
            this.btnClse.Size = new System.Drawing.Size(28, 28);
            this.btnClse.TabIndex = 35;
            this.btnClse.UseVisualStyleBackColor = true;
            this.btnClse.Click += new System.EventHandler(this.btnClse_Click);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(556, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 24);
            this.label8.TabIndex = 20;
            this.label8.Text = "Register";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Presentation.Properties.Resources.LogoCaptus2Main;
            this.pictureBox1.Location = new System.Drawing.Point(3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(107, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // brnCmPassword
            // 
            this.brnCmPassword.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.brnCmPassword.Image = global::Presentation.Properties.Resources.banner;
            this.brnCmPassword.Location = new System.Drawing.Point(563, 477);
            this.brnCmPassword.Name = "brnCmPassword";
            this.brnCmPassword.Size = new System.Drawing.Size(226, 43);
            this.brnCmPassword.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.brnCmPassword.TabIndex = 18;
            this.brnCmPassword.TabStop = false;
            // 
            // brnPassword
            // 
            this.brnPassword.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.brnPassword.Image = global::Presentation.Properties.Resources.banner;
            this.brnPassword.Location = new System.Drawing.Point(563, 410);
            this.brnPassword.Name = "brnPassword";
            this.brnPassword.Size = new System.Drawing.Size(226, 43);
            this.brnPassword.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.brnPassword.TabIndex = 17;
            this.brnPassword.TabStop = false;
            // 
            // brnUserName
            // 
            this.brnUserName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.brnUserName.Image = global::Presentation.Properties.Resources.banner;
            this.brnUserName.Location = new System.Drawing.Point(563, 346);
            this.brnUserName.Name = "brnUserName";
            this.brnUserName.Size = new System.Drawing.Size(226, 43);
            this.brnUserName.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.brnUserName.TabIndex = 16;
            this.brnUserName.TabStop = false;
            // 
            // brnPhNumber
            // 
            this.brnPhNumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.brnPhNumber.Image = global::Presentation.Properties.Resources.banner;
            this.brnPhNumber.Location = new System.Drawing.Point(563, 284);
            this.brnPhNumber.Name = "brnPhNumber";
            this.brnPhNumber.Size = new System.Drawing.Size(226, 43);
            this.brnPhNumber.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.brnPhNumber.TabIndex = 15;
            this.brnPhNumber.TabStop = false;
            // 
            // brnEmail
            // 
            this.brnEmail.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.brnEmail.Image = global::Presentation.Properties.Resources.banner;
            this.brnEmail.Location = new System.Drawing.Point(563, 226);
            this.brnEmail.Name = "brnEmail";
            this.brnEmail.Size = new System.Drawing.Size(226, 43);
            this.brnEmail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.brnEmail.TabIndex = 14;
            this.brnEmail.TabStop = false;
            // 
            // brnLastName
            // 
            this.brnLastName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.brnLastName.Image = global::Presentation.Properties.Resources.banner;
            this.brnLastName.Location = new System.Drawing.Point(563, 167);
            this.brnLastName.Name = "brnLastName";
            this.brnLastName.Size = new System.Drawing.Size(226, 43);
            this.brnLastName.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.brnLastName.TabIndex = 13;
            this.brnLastName.TabStop = false;
            // 
            // BnrName
            // 
            this.BnrName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BnrName.Image = global::Presentation.Properties.Resources.banner;
            this.BnrName.Location = new System.Drawing.Point(563, 109);
            this.BnrName.Name = "BnrName";
            this.BnrName.Size = new System.Drawing.Size(226, 43);
            this.BnrName.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BnrName.TabIndex = 12;
            this.BnrName.TabStop = false;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(412, 297);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 19);
            this.label7.TabIndex = 11;
            this.label7.Text = "Phone Number";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(412, 492);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 19);
            this.label6.TabIndex = 10;
            this.label6.Text = "Confirm Password";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(412, 423);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Password";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(412, 358);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 19);
            this.label4.TabIndex = 8;
            this.label4.Text = "Username";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(412, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "Email";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(412, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "Last Name";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(412, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "First Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // frmRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 650);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmRegister";
            this.Text = "frmRegister";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnReply)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnRegister)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnCmPassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnPassword)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnUserName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnPhNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnEmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brnLastName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BnrName)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox BnrName;
        private System.Windows.Forms.PictureBox brnCmPassword;
        private System.Windows.Forms.PictureBox brnPassword;
        private System.Windows.Forms.PictureBox brnUserName;
        private System.Windows.Forms.PictureBox brnPhNumber;
        private System.Windows.Forms.PictureBox brnEmail;
        private System.Windows.Forms.PictureBox brnLastName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox btnRegister;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtCnPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPhNumber;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.PictureBox btnReply;
        private System.Windows.Forms.Button btnRestaurar;
        private System.Windows.Forms.Button btnMaximizarbtnMaximizar;
        private System.Windows.Forms.Button btnMinimizar;
        private System.Windows.Forms.Button btnClse;
    }
}