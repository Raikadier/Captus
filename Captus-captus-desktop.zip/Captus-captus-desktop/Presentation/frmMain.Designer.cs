﻿namespace Presentation
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnChatBot = new System.Windows.Forms.Button();
            this.btnAddTask = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.btnTaskList = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.picLogoCaptus = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnRestaurar = new System.Windows.Forms.Button();
            this.btnMaximizar = new System.Windows.Forms.Button();
            this.btnMinimizar = new System.Windows.Forms.Button();
            this.btnClse = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelContenedor = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.cmbMes = new System.Windows.Forms.ComboBox();
            this.btnAlternarVista = new System.Windows.Forms.Panel();
            this.Icono = new System.Windows.Forms.Panel();
            this.lblAlternarVista = new System.Windows.Forms.Label();
            this.cmbAnio = new System.Windows.Forms.ComboBox();
            this.panelCalendario = new System.Windows.Forms.Panel();
            this.tblCalendario = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panelTareas = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogoCaptus)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMenu)).BeginInit();
            this.panelContenedor.SuspendLayout();
            this.panel44.SuspendLayout();
            this.btnAlternarVista.SuspendLayout();
            this.panelCalendario.SuspendLayout();
            this.tblCalendario.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(33, 150, 83);
            this.panel1.Controls.Add(this.btnHome);
            this.panel1.Controls.Add(this.btnCalcular);
            this.panel1.Controls.Add(this.btnChatBot);
            this.panel1.Controls.Add(this.btnAddTask);
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.btnProfile);
            this.panel1.Controls.Add(this.btnTaskList);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.picLogoCaptus);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(204, 561);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.Green;
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.btnHome.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.Honeydew;
            this.btnHome.Image = global::Presentation.Properties.Resources.iconsHome;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(0, 191);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(210, 34);
            this.btnHome.TabIndex = 50;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.FlatAppearance.BorderSize = 0;
            this.btnCalcular.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnCalcular.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalcular.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.ForeColor = System.Drawing.Color.Honeydew;
            this.btnCalcular.Image = global::Presentation.Properties.Resources.iconNote;
            this.btnCalcular.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCalcular.Location = new System.Drawing.Point(0, 403);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(200, 40);
            this.btnCalcular.TabIndex = 49;
            this.btnCalcular.Text = "Note";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnChatBot
            // 
            this.btnChatBot.FlatAppearance.BorderSize = 0;
            this.btnChatBot.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnChatBot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChatBot.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChatBot.ForeColor = System.Drawing.Color.Honeydew;
            this.btnChatBot.Image = global::Presentation.Properties.Resources.iconBt;
            this.btnChatBot.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChatBot.Location = new System.Drawing.Point(0, 347);
            this.btnChatBot.Name = "btnChatBot";
            this.btnChatBot.Size = new System.Drawing.Size(200, 40);
            this.btnChatBot.TabIndex = 48;
            this.btnChatBot.Text = "ChatBot";
            this.btnChatBot.UseVisualStyleBackColor = true;
            this.btnChatBot.Click += new System.EventHandler(this.btnChatBot_Click_1);
            // 
            // btnAddTask
            // 
            this.btnAddTask.BackColor = System.Drawing.Color.Green;
            this.btnAddTask.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddTask.FlatAppearance.BorderSize = 0;
            this.btnAddTask.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.btnAddTask.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnAddTask.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddTask.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTask.ForeColor = System.Drawing.Color.Honeydew;
            this.btnAddTask.Image = global::Presentation.Properties.Resources.iconPlus;
            this.btnAddTask.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddTask.Location = new System.Drawing.Point(0, 241);
            this.btnAddTask.Name = "btnAddTask";
            this.btnAddTask.Size = new System.Drawing.Size(210, 34);
            this.btnAddTask.TabIndex = 46;
            this.btnAddTask.Text = "Add Task";
            this.btnAddTask.UseVisualStyleBackColor = false;
            this.btnAddTask.Click += new System.EventHandler(this.btnAddTask_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.Honeydew;
            this.btnLogout.Image = global::Presentation.Properties.Resources.iconOut2;
            this.btnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogout.Location = new System.Drawing.Point(0, 515);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(210, 39);
            this.btnLogout.TabIndex = 44;
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.ForeColor = System.Drawing.Color.Honeydew;
            this.btnProfile.Image = global::Presentation.Properties.Resources.iconProfile;
            this.btnProfile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProfile.Location = new System.Drawing.Point(0, 459);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(197, 40);
            this.btnProfile.TabIndex = 43;
            this.btnProfile.Text = "Profile";
            this.btnProfile.UseVisualStyleBackColor = true;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnTaskList
            // 
            this.btnTaskList.FlatAppearance.BorderSize = 0;
            this.btnTaskList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnTaskList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTaskList.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaskList.ForeColor = System.Drawing.Color.Honeydew;
            this.btnTaskList.Image = global::Presentation.Properties.Resources.iconListTsk;
            this.btnTaskList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTaskList.Location = new System.Drawing.Point(0, 291);
            this.btnTaskList.Name = "btnTaskList";
            this.btnTaskList.Size = new System.Drawing.Size(200, 40);
            this.btnTaskList.TabIndex = 41;
            this.btnTaskList.Text = "TaskList";
            this.btnTaskList.UseVisualStyleBackColor = true;
            this.btnTaskList.Click += new System.EventHandler(this.btnTaskList_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Honeydew;
            this.label1.Location = new System.Drawing.Point(57, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 19);
            this.label1.TabIndex = 31;
            this.label1.Text = "C A P T U S";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // picLogoCaptus
            // 
            this.picLogoCaptus.Image = global::Presentation.Properties.Resources.LogoCaptus2Main;
            this.picLogoCaptus.Location = new System.Drawing.Point(34, 0);
            this.picLogoCaptus.Name = "picLogoCaptus";
            this.picLogoCaptus.Size = new System.Drawing.Size(132, 97);
            this.picLogoCaptus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogoCaptus.TabIndex = 30;
            this.picLogoCaptus.TabStop = false;
            this.picLogoCaptus.Click += new System.EventHandler(this.picLogoCaptus_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnRestaurar);
            this.panel2.Controls.Add(this.btnMaximizar);
            this.panel2.Controls.Add(this.btnMinimizar);
            this.panel2.Controls.Add(this.btnClse);
            this.panel2.Controls.Add(this.btnMenu);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(204, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(786, 43);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel2_MouseDown);
            // 

            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panelContenedor
            // 
            this.panelContenedor.BackColor = System.Drawing.Color.White;
            this.panelContenedor.Controls.Add(this.panelTareas);
            this.panelContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContenedor.Location = new System.Drawing.Point(210, 43);
            this.panelContenedor.Name = "panelContenedor";
            this.panelContenedor.Size = new System.Drawing.Size(780, 518);
            this.panelContenedor.TabIndex = 2;
            this.panelContenedor.Paint += new System.Windows.Forms.PaintEventHandler(this.panelContenedor_Paint);
            // 
            // panelTareas
            // 
            this.panelTareas.AutoScroll = true;
            this.panelTareas.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelTareas.Location = new System.Drawing.Point(49, 84);
            this.panelTareas.Name = "panelTareas";
            this.panelTareas.Size = new System.Drawing.Size(700, 400);
            this.panelTareas.TabIndex = 0;
            this.panelTareas.WrapContents = false;
            this.panelTareas.Paint += new System.Windows.Forms.PaintEventHandler(this.panelTareas_Paint);
            // 
            // btnRestaurar
            // 
            this.btnRestaurar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRestaurar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRestaurar.FlatAppearance.BorderSize = 0;
            this.btnRestaurar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnRestaurar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnRestaurar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRestaurar.Image = global::Presentation.Properties.Resources.btnRestaurar;
            this.btnRestaurar.Location = new System.Drawing.Point(712, 2);
            this.btnRestaurar.Name = "btnRestaurar";
            this.btnRestaurar.Size = new System.Drawing.Size(30, 35);
            this.btnRestaurar.TabIndex = 34;
            this.btnRestaurar.UseVisualStyleBackColor = true;
            this.btnRestaurar.Visible = false;
            this.btnRestaurar.Click += new System.EventHandler(this.btnRestaurar_Click_1);
            // 
            // btnMaximizar
            // 
            this.btnMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaximizar.FlatAppearance.BorderSize = 0;
            this.btnMaximizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnMaximizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnMaximizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximizar.Image = global::Presentation.Properties.Resources.icons8_maximize_window_50__1_;
            this.btnMaximizar.Location = new System.Drawing.Point(711, 2);
            this.btnMaximizar.Name = "btnMaximizar";
            this.btnMaximizar.Size = new System.Drawing.Size(30, 35);
            this.btnMaximizar.TabIndex = 33;
            this.btnMaximizar.UseVisualStyleBackColor = true;
            this.btnMaximizar.Click += new System.EventHandler(this.btnMaximizar_Click_1);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimizar.FlatAppearance.BorderSize = 0;
            this.btnMinimizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.btnMinimizar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimizar.Image = global::Presentation.Properties.Resources.btnMinimizar;
            this.btnMinimizar.Location = new System.Drawing.Point(684, 8);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(23, 25);
            this.btnMinimizar.TabIndex = 32;
            this.btnMinimizar.UseVisualStyleBackColor = true;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click_1);
            // 
            // btnClse
            // 
            this.btnClse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClse.FlatAppearance.BorderSize = 0;
            this.btnClse.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnClse.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnClse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClse.Image = global::Presentation.Properties.Resources.icons8_close_window_50__2_;
            this.btnClse.Location = new System.Drawing.Point(746, 5);
            this.btnClse.Name = "btnClse";
            this.btnClse.Size = new System.Drawing.Size(28, 28);
            this.btnClse.TabIndex = 31;
            this.btnClse.UseVisualStyleBackColor = true;
            this.btnClse.Click += new System.EventHandler(this.btnClse_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenu.Image = global::Presentation.Properties.Resources.menu_hamburguesa;
            this.btnMenu.Location = new System.Drawing.Point(3, 3);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(50, 38);
            this.btnMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMenu.TabIndex = 29;
            this.btnMenu.TabStop = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // timer1
            // 

            this.btnHome.BackColor = System.Drawing.Color.FromArgb(33, 150, 83);
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.btnHome.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(111, 207, 151);
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.Honeydew;
            this.btnHome.Image = global::Presentation.Properties.Resources.iconsHome;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(0, 168);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(210, 34);
            this.btnHome.TabIndex = 50;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);

            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);

            // 
            // panelContenedor
            // 
            this.panelContenedor.Controls.Add(this.panel44);
            this.panelContenedor.Controls.Add(this.panelCalendario);
            this.panelContenedor.Controls.Add(this.panelTareas);
            this.panelContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContenedor.Location = new System.Drawing.Point(204, 43);
            this.panelContenedor.Name = "panelContenedor";
            this.panelContenedor.Size = new System.Drawing.Size(786, 518);
            this.panelContenedor.TabIndex = 2;
            this.panelContenedor.Paint += new System.Windows.Forms.PaintEventHandler(this.panelContenedor_Paint);
            // 
            // panel44
            // 
            this.panel44.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel44.Controls.Add(this.cmbMes);
            this.panel44.Controls.Add(this.btnAlternarVista);
            this.panel44.Controls.Add(this.cmbAnio);
            this.panel44.Location = new System.Drawing.Point(0, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(786, 52);
            this.panel44.TabIndex = 4;
            // 
            // cmbMes
            // 
            this.cmbMes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbMes.BackColor = System.Drawing.Color.Honeydew;
            this.cmbMes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbMes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbMes.FormattingEnabled = true;
            this.cmbMes.Location = new System.Drawing.Point(657, 21);
            this.cmbMes.Name = "cmbMes";
            this.cmbMes.Size = new System.Drawing.Size(108, 21);
            this.cmbMes.TabIndex = 2;
            // 
            // btnAlternarVista
            // 
            this.btnAlternarVista.Controls.Add(this.Icono);
            this.btnAlternarVista.Controls.Add(this.lblAlternarVista);
            this.btnAlternarVista.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlternarVista.Location = new System.Drawing.Point(46, 16);
            this.btnAlternarVista.Name = "btnAlternarVista";
            this.btnAlternarVista.Size = new System.Drawing.Size(233, 30);
            this.btnAlternarVista.TabIndex = 1;
            this.btnAlternarVista.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnAlternarVista_MouseClick);
            // 
            // Icono
            // 
            this.Icono.BackgroundImage = global::Presentation.Properties.Resources.Calendario;
            this.Icono.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icono.Location = new System.Drawing.Point(59, 5);
            this.Icono.Name = "Icono";
            this.Icono.Size = new System.Drawing.Size(20, 20);
            this.Icono.TabIndex = 1;
            this.Icono.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnAlternarVista_MouseClick);
            // 
            // lblAlternarVista
            // 
            this.lblAlternarVista.AutoSize = true;
            this.lblAlternarVista.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblAlternarVista.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlternarVista.Location = new System.Drawing.Point(87, 4);
            this.lblAlternarVista.Name = "lblAlternarVista";
            this.lblAlternarVista.Size = new System.Drawing.Size(114, 21);
            this.lblAlternarVista.TabIndex = 0;
            this.lblAlternarVista.Text = "Ver calendario";
            this.lblAlternarVista.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnAlternarVista_MouseClick);
            // 
            // cmbAnio
            // 
            this.cmbAnio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbAnio.BackColor = System.Drawing.Color.Honeydew;
            this.cmbAnio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbAnio.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmbAnio.FormattingEnabled = true;
            this.cmbAnio.Location = new System.Drawing.Point(520, 21);
            this.cmbAnio.Name = "cmbAnio";
            this.cmbAnio.Size = new System.Drawing.Size(104, 21);
            this.cmbAnio.TabIndex = 3;
            // 
            // panelCalendario
            // 
            this.panelCalendario.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelCalendario.Controls.Add(this.tblCalendario);
            this.panelCalendario.Location = new System.Drawing.Point(68, 54);
            this.panelCalendario.Name = "panelCalendario";
            this.panelCalendario.Size = new System.Drawing.Size(638, 408);
            this.panelCalendario.TabIndex = 0;
            // 
            // tblCalendario
            // 
            this.tblCalendario.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tblCalendario.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tblCalendario.ColumnCount = 7;
            this.tblCalendario.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblCalendario.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblCalendario.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblCalendario.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblCalendario.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblCalendario.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblCalendario.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblCalendario.Controls.Add(this.panel3, 0, 1);
            this.tblCalendario.Controls.Add(this.panel4, 0, 0);
            this.tblCalendario.Controls.Add(this.panel5, 1, 0);
            this.tblCalendario.Controls.Add(this.panel6, 2, 0);
            this.tblCalendario.Controls.Add(this.panel7, 3, 0);
            this.tblCalendario.Controls.Add(this.panel8, 4, 0);
            this.tblCalendario.Controls.Add(this.panel9, 5, 0);
            this.tblCalendario.Controls.Add(this.panel10, 6, 0);
            this.tblCalendario.Controls.Add(this.panel11, 1, 1);
            this.tblCalendario.Controls.Add(this.panel12, 2, 1);
            this.tblCalendario.Controls.Add(this.panel13, 3, 1);
            this.tblCalendario.Controls.Add(this.panel14, 4, 1);
            this.tblCalendario.Controls.Add(this.panel15, 5, 1);
            this.tblCalendario.Controls.Add(this.panel16, 6, 1);
            this.tblCalendario.Controls.Add(this.panel17, 0, 2);
            this.tblCalendario.Controls.Add(this.panel18, 1, 2);
            this.tblCalendario.Controls.Add(this.panel19, 2, 2);
            this.tblCalendario.Controls.Add(this.panel20, 0, 3);
            this.tblCalendario.Controls.Add(this.panel21, 0, 4);
            this.tblCalendario.Controls.Add(this.panel22, 0, 5);
            this.tblCalendario.Controls.Add(this.panel23, 1, 3);
            this.tblCalendario.Controls.Add(this.panel24, 1, 4);
            this.tblCalendario.Controls.Add(this.panel25, 1, 5);
            this.tblCalendario.Controls.Add(this.panel26, 2, 3);
            this.tblCalendario.Controls.Add(this.panel27, 2, 4);
            this.tblCalendario.Controls.Add(this.panel28, 3, 2);
            this.tblCalendario.Controls.Add(this.panel29, 2, 5);
            this.tblCalendario.Controls.Add(this.panel30, 3, 3);
            this.tblCalendario.Controls.Add(this.panel31, 3, 4);
            this.tblCalendario.Controls.Add(this.panel32, 3, 5);
            this.tblCalendario.Controls.Add(this.panel33, 4, 2);
            this.tblCalendario.Controls.Add(this.panel34, 5, 2);
            this.tblCalendario.Controls.Add(this.panel35, 6, 2);
            this.tblCalendario.Controls.Add(this.panel36, 4, 3);
            this.tblCalendario.Controls.Add(this.panel37, 4, 4);
            this.tblCalendario.Controls.Add(this.panel38, 4, 5);
            this.tblCalendario.Controls.Add(this.panel39, 5, 3);
            this.tblCalendario.Controls.Add(this.panel40, 6, 3);
            this.tblCalendario.Controls.Add(this.panel41, 5, 4);
            this.tblCalendario.Controls.Add(this.panel42, 6, 4);
            this.tblCalendario.Controls.Add(this.panel43, 5, 5);
            this.tblCalendario.Controls.Add(this.flowLayoutPanel1, 6, 5);
            this.tblCalendario.Location = new System.Drawing.Point(0, 0);
            this.tblCalendario.Name = "tblCalendario";
            this.tblCalendario.RowCount = 6;
            this.tblCalendario.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tblCalendario.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tblCalendario.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tblCalendario.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tblCalendario.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tblCalendario.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tblCalendario.Size = new System.Drawing.Size(638, 408);
            this.tblCalendario.TabIndex = 3;
            this.tblCalendario.Layout += new System.Windows.Forms.LayoutEventHandler(this.tblCalendario_Layout);
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(4, 71);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(83, 60);
            this.panel3.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.PeachPuff;
            this.panel4.Controls.Add(this.label2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(83, 60);
            this.panel4.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(14, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Lunes";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.PeachPuff;
            this.panel5.Controls.Add(this.label3);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(94, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(83, 60);
            this.panel5.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(11, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "Martes";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.PeachPuff;
            this.panel6.Controls.Add(this.label4);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(184, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(83, 60);
            this.panel6.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(1, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 19);
            this.label4.TabIndex = 2;
            this.label4.Text = "Miercoles";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.PeachPuff;
            this.panel7.Controls.Add(this.label5);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(274, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(83, 60);
            this.panel7.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(13, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 19);
            this.label5.TabIndex = 3;
            this.label5.Text = "Jueves";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.PeachPuff;
            this.panel8.Controls.Add(this.label6);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(364, 4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(83, 60);
            this.panel8.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(9, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 19);
            this.label6.TabIndex = 4;
            this.label6.Text = "Viernes";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.PeachPuff;
            this.panel9.Controls.Add(this.label7);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(454, 4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(83, 60);
            this.panel9.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(11, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 19);
            this.label7.TabIndex = 5;
            this.label7.Text = "Sabado";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.PeachPuff;
            this.panel10.Controls.Add(this.label8);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(544, 4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(90, 60);
            this.panel10.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(4, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 19);
            this.label8.TabIndex = 6;
            this.label8.Text = "Domingo";
            // 
            // panel11
            // 
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(94, 71);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(83, 60);
            this.panel11.TabIndex = 15;
            // 
            // panel12
            // 
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(184, 71);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(83, 60);
            this.panel12.TabIndex = 16;
            // 
            // panel13
            // 
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(274, 71);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(83, 60);
            this.panel13.TabIndex = 17;
            // 
            // panel14
            // 
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(364, 71);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(83, 60);
            this.panel14.TabIndex = 18;
            // 
            // panel15
            // 
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(454, 71);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(83, 60);
            this.panel15.TabIndex = 19;
            // 
            // panel16
            // 
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(544, 71);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(90, 60);
            this.panel16.TabIndex = 20;
            // 
            // panel17
            // 
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(4, 138);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(83, 60);
            this.panel17.TabIndex = 21;
            // 
            // panel18
            // 
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(94, 138);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(83, 60);
            this.panel18.TabIndex = 22;
            // 
            // panel19
            // 
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(184, 138);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(83, 60);
            this.panel19.TabIndex = 23;
            // 
            // panel20
            // 
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(4, 205);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(83, 60);
            this.panel20.TabIndex = 24;
            // 
            // panel21
            // 
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(4, 272);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(83, 60);
            this.panel21.TabIndex = 25;
            // 
            // panel22
            // 
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(4, 339);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(83, 65);
            this.panel22.TabIndex = 26;
            // 
            // panel23
            // 
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(94, 205);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(83, 60);
            this.panel23.TabIndex = 27;
            // 
            // panel24
            // 
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(94, 272);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(83, 60);
            this.panel24.TabIndex = 28;
            // 
            // panel25
            // 
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(94, 339);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(83, 65);
            this.panel25.TabIndex = 29;
            // 
            // panel26
            // 
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(184, 205);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(83, 60);
            this.panel26.TabIndex = 30;
            // 
            // panel27
            // 
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(184, 272);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(83, 60);
            this.panel27.TabIndex = 31;
            // 
            // panel28
            // 
            this.panel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel28.Location = new System.Drawing.Point(274, 138);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(83, 60);
            this.panel28.TabIndex = 32;
            // 
            // panel29
            // 
            this.panel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel29.Location = new System.Drawing.Point(184, 339);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(83, 65);
            this.panel29.TabIndex = 33;
            // 
            // panel30
            // 
            this.panel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel30.Location = new System.Drawing.Point(274, 205);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(83, 60);
            this.panel30.TabIndex = 34;
            // 
            // panel31
            // 
            this.panel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel31.Location = new System.Drawing.Point(274, 272);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(83, 60);
            this.panel31.TabIndex = 35;
            // 
            // panel32
            // 
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(274, 339);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(83, 65);
            this.panel32.TabIndex = 36;
            // 
            // panel33
            // 
            this.panel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel33.Location = new System.Drawing.Point(364, 138);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(83, 60);
            this.panel33.TabIndex = 37;
            // 
            // panel34
            // 
            this.panel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel34.Location = new System.Drawing.Point(454, 138);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(83, 60);
            this.panel34.TabIndex = 38;
            // 
            // panel35
            // 
            this.panel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel35.Location = new System.Drawing.Point(544, 138);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(90, 60);
            this.panel35.TabIndex = 39;
            // 
            // panel36
            // 
            this.panel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel36.Location = new System.Drawing.Point(364, 205);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(83, 60);
            this.panel36.TabIndex = 40;
            // 
            // panel37
            // 
            this.panel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel37.Location = new System.Drawing.Point(364, 272);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(83, 60);
            this.panel37.TabIndex = 41;
            // 
            // panel38
            // 
            this.panel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel38.Location = new System.Drawing.Point(364, 339);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(83, 65);
            this.panel38.TabIndex = 42;
            // 
            // panel39
            // 
            this.panel39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel39.Location = new System.Drawing.Point(454, 205);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(83, 60);
            this.panel39.TabIndex = 43;
            // 
            // panel40
            // 
            this.panel40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel40.Location = new System.Drawing.Point(544, 205);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(90, 60);
            this.panel40.TabIndex = 44;
            // 
            // panel41
            // 
            this.panel41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel41.Location = new System.Drawing.Point(454, 272);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(83, 60);
            this.panel41.TabIndex = 45;
            // 
            // panel42
            // 
            this.panel42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel42.Location = new System.Drawing.Point(544, 272);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(90, 60);
            this.panel42.TabIndex = 46;
            // 
            // panel43
            // 
            this.panel43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel43.Location = new System.Drawing.Point(454, 339);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(83, 65);
            this.panel43.TabIndex = 47;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(544, 339);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(90, 65);
            this.flowLayoutPanel1.TabIndex = 48;
            // 
            // panelTareas
            // 


            this.btnChatBot.FlatAppearance.BorderSize = 0;
            this.btnChatBot.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnChatBot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChatBot.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChatBot.ForeColor = System.Drawing.Color.Honeydew;
            this.btnChatBot.Image = global::Presentation.Properties.Resources.iconBt;
            this.btnChatBot.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChatBot.Location = new System.Drawing.Point(0, 331);
            this.btnChatBot.Name = "btnChatBot";
            this.btnChatBot.Size = new System.Drawing.Size(200, 40);
            this.btnChatBot.TabIndex = 48;
            this.btnChatBot.Text = "ChatBot";
            this.btnChatBot.UseVisualStyleBackColor = true;
            this.btnChatBot.Click += new System.EventHandler(this.btnChatBot_Click_1);
            // 
            // btnAddTask
            // 
            this.btnAddTask.BackColor = System.Drawing.Color.FromArgb(33, 150, 83);
            this.btnAddTask.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddTask.FlatAppearance.BorderSize = 0;
            this.btnAddTask.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.btnAddTask.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(111, 207, 151);
            this.btnAddTask.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddTask.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTask.ForeColor = System.Drawing.Color.Honeydew;
            this.btnAddTask.Image = global::Presentation.Properties.Resources.iconPlus;
            this.btnAddTask.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddTask.Location = new System.Drawing.Point(0, 224);
            this.btnAddTask.Name = "btnAddTask";
            this.btnAddTask.Size = new System.Drawing.Size(210, 34);
            this.btnAddTask.TabIndex = 46;
            this.btnAddTask.Text = "Add Task";
            this.btnAddTask.UseVisualStyleBackColor = false;
            this.btnAddTask.Click += new System.EventHandler(this.btnAddTask_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.Honeydew;
            this.btnLogout.Image = global::Presentation.Properties.Resources.iconOut2;
            this.btnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogout.Location = new System.Drawing.Point(0, 494);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(197, 64);
            this.btnLogout.TabIndex = 44;
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.ForeColor = System.Drawing.Color.Honeydew;
            this.btnProfile.Image = global::Presentation.Properties.Resources.iconProfile;
            this.btnProfile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProfile.Location = new System.Drawing.Point(0, 447);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(197, 40);
            this.btnProfile.TabIndex = 43;
            this.btnProfile.Text = "Profile";
            this.btnProfile.UseVisualStyleBackColor = true;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // btnTaskList
            // 
            this.btnTaskList.FlatAppearance.BorderSize = 0;
            this.btnTaskList.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnTaskList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTaskList.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaskList.ForeColor = System.Drawing.Color.Honeydew;
            this.btnTaskList.Image = global::Presentation.Properties.Resources.iconListTsk;
            this.btnTaskList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTaskList.Location = new System.Drawing.Point(0, 273);
            this.btnTaskList.Name = "btnTaskList";
            this.btnTaskList.Size = new System.Drawing.Size(200, 40);
            this.btnTaskList.TabIndex = 41;
            this.btnTaskList.Text = "TaskList";
            this.btnTaskList.UseVisualStyleBackColor = true;
            this.btnTaskList.Click += new System.EventHandler(this.btnTaskList_Click);
            // 
            // picLogoCaptus
            // 
            this.picLogoCaptus.Image = global::Presentation.Properties.Resources.lgCaptus;
            this.picLogoCaptus.Location = new System.Drawing.Point(34, 0);
            this.picLogoCaptus.Name = "picLogoCaptus";
            this.picLogoCaptus.Size = new System.Drawing.Size(132, 97);
            this.picLogoCaptus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogoCaptus.TabIndex = 30;
            this.picLogoCaptus.TabStop = false;
            this.picLogoCaptus.Click += new System.EventHandler(this.picLogoCaptus_Click);


            this.panelTareas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));

            this.panelTareas.AutoScroll = true;
            this.panelTareas.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelTareas.Location = new System.Drawing.Point(46, 61);
            this.panelTareas.Name = "panelTareas";
            this.panelTareas.Size = new System.Drawing.Size(677, 430);
            this.panelTareas.TabIndex = 0;
            this.panelTareas.WrapContents = false;
            this.panelTareas.Paint += new System.Windows.Forms.PaintEventHandler(this.panelTareas_Paint);

            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(990, 561);
            this.Controls.Clear();
            this.Controls.Add(this.panelContenedor);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Text = "frmMain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogoCaptus)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnMenu)).EndInit();
            this.panelContenedor.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.btnAlternarVista.ResumeLayout(false);
            this.btnAlternarVista.PerformLayout();
            this.panelCalendario.ResumeLayout(false);
            this.tblCalendario.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox btnMenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picLogoCaptus;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnTaskList;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Panel panelContenedor;
        private System.Windows.Forms.FlowLayoutPanel panelTareas;
        private System.Windows.Forms.Button btnAddTask;
        private System.Windows.Forms.Button btnChatBot;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnClse;
        private System.Windows.Forms.Button btnMinimizar;
        private System.Windows.Forms.Button btnMaximizar;
        private System.Windows.Forms.Button btnRestaurar;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel panelCalendario;
        private System.Windows.Forms.Panel btnAlternarVista;
        private System.Windows.Forms.Panel Icono;
        private System.Windows.Forms.Label lblAlternarVista;
        private System.Windows.Forms.ComboBox cmbAnio;
        private System.Windows.Forms.ComboBox cmbMes;
        private System.Windows.Forms.TableLayoutPanel tblCalendario;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel44;
    }
}